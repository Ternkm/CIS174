﻿using System.Collections.Generic;

namespace OlympicFlagsMcMillan.Models
{
    public static class TicketRepository
    {
        private static readonly List<Ticket> tickets = new List<Ticket>
        {
            new Ticket { Name = "Setup Project", Description = "Create new project in Visual Studio", SprintNumber = 1, Points = 3, Status = "Done" },
            new Ticket { Name = "Add Home Page", Description = "Create index view", SprintNumber = 1, Points = 5, Status = "In Progress" }
        };

        public static List<Ticket> Tickets => tickets;

        public static void AddTicket(Ticket ticket)
        {
            if (ticket != null)
            {
                tickets.Add(ticket);
            }
        }
    }
}
