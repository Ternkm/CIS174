﻿namespace OlympicFlagsMcMillan.Models
{
    public class Country
    {
        public string Name { get; set; }
        public string Game { get; set; }
        public string Sport { get; set; }
        public string Category { get; set; }
        public string FlagUrl { get; set; }
    }
}
