﻿using System.Collections.Generic;

namespace OlympicFlagsMcMillan.Models
{
    public static class CountryRepository
    {
        public static List<Country> GetCountries() => new List<Country>
        {
            new Country { Name="Canada", Game="Winter Olympics", Sport="Curling", Category="Indoor", FlagUrl="/images/canada.png" },
            new Country { Name="Sweden", Game="Winter Olympics", Sport="Curling", Category="Indoor", FlagUrl="/images/sweden.png" },
            new Country { Name="Great Britain", Game="Winter Olympics", Sport="Curling", Category="Indoor", FlagUrl="/images/uk.png" },
            new Country { Name="Jamaica", Game="Winter Olympics", Sport="Bobsleigh", Category="Outdoor", FlagUrl="/images/jamaica.png" },
            new Country { Name="Italy", Game="Winter Olympics", Sport="Bobsleigh", Category="Outdoor", FlagUrl="/images/italy.png" },
            new Country { Name="Japan", Game="Winter Olympics", Sport="Bobsleigh", Category="Outdoor", FlagUrl="/images/japan.png" },
            new Country { Name="Germany", Game="Summer Olympics", Sport="Diving", Category="Indoor", FlagUrl="/images/germany.png" },
            new Country { Name="China", Game="Summer Olympics", Sport="Diving", Category="Indoor", FlagUrl="/images/china.png" },
            new Country { Name="Mexico", Game="Summer Olympics", Sport="Diving", Category="Indoor", FlagUrl="/images/mexico.png" },
            new Country { Name="Brazil", Game="Summer Olympics", Sport="Road Cycling", Category="Outdoor", FlagUrl="/images/brazil.png" },
            new Country { Name="Netherlands", Game="Summer Olympics", Sport="Cycling", Category="Outdoor", FlagUrl="/images/netherlands.png" },
            new Country { Name="USA", Game="Summer Olympics", Sport="Road Cycling", Category="Outdoor", FlagUrl="/images/usa.png" },
            new Country { Name="Thailand", Game="Paralympics", Sport="Archery", Category="Indoor", FlagUrl="/images/thailand.png" },
            new Country { Name="Uruguay", Game="Paralympics", Sport="Archery", Category="Indoor", FlagUrl="/images/uruguay.png" },
            new Country { Name="Ukraine", Game="Paralympics", Sport="Archery", Category="Indoor", FlagUrl="/images/ukraine.png" },
            new Country { Name="Austria", Game="Paralympics", Sport="Canoe Sprint", Category="Outdoor", FlagUrl="/images/austria.png" },
            new Country { Name="Pakistan", Game="Paralympics", Sport="Canoe Sprint", Category="Outdoor", FlagUrl="/images/pakistan.png" },
            new Country { Name="Zimbabwe", Game="Paralympics", Sport="Canoe Sprint", Category="Outdoor", FlagUrl="/images/zimbabwe.png" },
            new Country { Name="France", Game="Youth Olympic Games", Sport="Breakdancing", Category="Indoor", FlagUrl="/images/france.png" },
            new Country { Name="Cyprus", Game="Youth Olympic Games", Sport="Breakdancing", Category="Indoor", FlagUrl="/images/cyprus.png" },
            new Country { Name="Russia", Game="Youth Olympic Games", Sport="Breakdancing", Category="Indoor", FlagUrl="/images/russia.png" },
            new Country { Name="Finland", Game="Youth Olympic Games", Sport="Skateboarding", Category="Outdoor", FlagUrl="/images/finland.png" },
            new Country { Name="Slovakia", Game="Youth Olympic Games", Sport="Skateboarding", Category="Outdoor", FlagUrl="/images/slovakia.png" },
            new Country { Name="Portugal", Game="Youth Olympic Games", Sport="Skateboarding", Category="Outdoor", FlagUrl="/images/portugal.png" },
        };
    }
}
