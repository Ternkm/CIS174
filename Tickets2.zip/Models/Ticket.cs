﻿using System.ComponentModel.DataAnnotations;

namespace OlympicFlagsMcMillan.Models
{
    public class Ticket
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Ticket name is required.")]
        [StringLength(50, ErrorMessage = "Name cannot exceed 50 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        [StringLength(200, ErrorMessage = "Description cannot exceed 200 characters.")]
        public string Description { get; set; }

        [Range(1, 10, ErrorMessage = "Sprint number must be between 1 and 10.")]
        public int SprintNumber { get; set; }

        [Range(1, 20, ErrorMessage = "Points must be between 1 and 20.")]
        public int Points { get; set; }

        [Required(ErrorMessage = "Status is required.")]
        [RegularExpression("To Do|In Progress|QA|Done",
            ErrorMessage = "Status must be To Do, In Progress, QA, or Done.")]
        public string Status { get; set; } = "To Do";
    } 
} 
