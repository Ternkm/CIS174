﻿using Microsoft.AspNetCore.Mvc;
using OlympicFlagsMcMillan.Models; 
using System.Collections.Generic;

namespace OlympicFlagsMcMillan.Controllers
{
    public class TicketsController : Controller
    {
       
        private static List<Ticket> tickets = new List<Ticket>();

        public IActionResult Index()
        {
            return View(tickets); 
        }

        [HttpGet]
        public IActionResult AddTicket()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddTicket(Ticket newTicket)
        {
            if (ModelState.IsValid)
            {
                tickets.Add(newTicket);
                return RedirectToAction("Index");
            }
            return View(newTicket);
        }
    }
}
