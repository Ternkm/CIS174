﻿using Microsoft.AspNetCore.Mvc;
using OlympicFlagsMcMillan.Models;
using OlympicFlagsMcMillan.Helpers;
using System.Collections.Generic;

namespace OlympicFlagsMcMillan.Controllers
{
    public class FavoritesController : Controller
    {
        public IActionResult Index()
        {
            var favorites = HttpContext.Session.GetObjectFromJson<List<OlympicGames>>("Favorites") ?? new List<OlympicGames>();
            return View(favorites);
        }

        public IActionResult Clear()
        {
            HttpContext.Session.SetObjectAsJson("Favorites", new List<OlympicGames>());
            return RedirectToAction("Index");
        }
    }
}
