using Microsoft.AspNetCore.Mvc;
using OlympicFlagsMcMillan.Models;
using OlympicFlagsMcMillan.Helpers;
using System.Collections.Generic;
using System.Linq;

namespace OlympicFlagsMcMillan.Controllers
{
    public class HomeController : Controller
    {
        // -------------------- OLYMPIC GAMES SECTION --------------------
        public IActionResult Index(string game = "ALL", string category = "ALL")
        {
            var countries = CountryRepository.GetCountries();

            // Filter
            if (!string.IsNullOrEmpty(game) && game != "ALL")
                countries = countries.Where(c => c.Game == game).ToList();

            if (!string.IsNullOrEmpty(category) && category != "ALL")
                countries = countries.Where(c => c.Category == category).ToList();

            countries = countries.OrderBy(c => c.Name).ToList();

            
            var viewModelList = countries.Select(c => new OlympicViewModel
            {
                Name = c.Name,
                FlagUrl = c.FlagUrl,
                Game = c.Game,
                Category = c.Category,
            }).ToList();

            ViewBag.Game = game;
            ViewBag.Category = category;

            return View(viewModelList);  
        }

        public IActionResult Details(string name)
        {
            var country = CountryRepository.GetCountries().FirstOrDefault(c => c.Name == name);
            if (country == null)
                return NotFound();

            return View(country);
        }

        [HttpPost]
        public IActionResult AddToFavorites(string name)
        {
            var country = CountryRepository.GetCountries().FirstOrDefault(c => c.Name == name);
            if (country == null)
                return RedirectToAction("Index");

            var favorites = HttpContext.Session.GetObjectFromJson<List<Country>>("Favorites") ?? new List<Country>();

            if (!favorites.Any(f => f.Name == country.Name))
            {
                favorites.Add(country);
                HttpContext.Session.SetObjectAsJson("Favorites", favorites);
            }

            return RedirectToAction("Index", "Favorites");
        }

        // -------------------- TICKET SYSTEM SECTION --------------------

        
        public IActionResult Tickets()
        {
            var tickets = TicketRepository.Tickets;
            return View(tickets);
        }

       
        [HttpGet]
        public IActionResult AddTicket()
        {
            return View();
        }

      
        [HttpPost]
        public IActionResult AddTicket(Ticket ticket)
        {
            if (ModelState.IsValid)
            {
               
                TicketRepository.AddTicket(ticket);

                TempData["Message"] = "Ticket added successfully!";
                return RedirectToAction("Tickets");
            }

           
            return View(ticket);
        }
    }
}
