﻿using System.Collections.Generic;
using OlympicFlagsMcMillan.Models;

namespace OlympicFlagsMcMillan.Models
{
    public static class TicketRepository
    {
        public static List<Ticket> Tickets = new List<Ticket>()
        {
            new Ticket { Name = "Setup Project", Description = "Create new project in Visual Studio", SprintNumber = 1, Points = 3, Status = "Done" },
            new Ticket { Name = "Add Home Page", Description = "Create index view", SprintNumber = 1, Points = 5, Status = "In Progress" }
        };

        public static void AddTicket(Ticket ticket)
        {
            Tickets.Add(ticket);
        }
    }
}
