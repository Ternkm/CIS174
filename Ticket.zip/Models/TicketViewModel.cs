﻿public class TicketViewModel
{
    public string Name { get; set; }
    public string Description { get; set; }
    public int SprintNumber { get; set; }
    public int Points { get; set; }
    public string Status { get; set; }
}
