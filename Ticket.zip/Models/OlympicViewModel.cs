﻿namespace OlympicFlagsMcMillan.Models
{
    public class OlympicViewModel
    {
        public string Name { get; set; }       
        public string FlagUrl { get; set; }    
        public string Game { get; set; }
        public string Category { get; set; }
    }
}
