﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

public class Assignment6Controller : Controller
{
    public IActionResult Index(int accessLevel)
    {
        var students = new List<Student>
        {
            new Student { FirstName = "Alice", LastName = "Smith", Grade = 90 },
            new Student { FirstName = "Bob", LastName = "Jones", Grade = 85 },
            new Student { FirstName = "Charlie", LastName = "Brown", Grade = 92 },
            new Student { FirstName = "Diana", LastName = "White", Grade = 88 }
        };

        var viewModel = new StudentViewModel
        {
            AccessLevel = accessLevel,
            Students = students
        };

        return View(viewModel);
    }
}
