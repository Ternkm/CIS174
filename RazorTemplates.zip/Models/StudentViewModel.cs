﻿using System.Collections.Generic;

public class StudentViewModel
{
    public int AccessLevel { get; set; }
    public List<Student> Students { get; set; }
}
