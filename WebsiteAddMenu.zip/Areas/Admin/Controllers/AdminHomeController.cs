﻿using Microsoft.AspNetCore.Mvc;

namespace FirstResponsiveWebAppMcMillan.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class AdminHomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Title"] = "Admin Home";
            return View();
        }
    }
}
