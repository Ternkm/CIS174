﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FirstResponsiveWebAppMcMillan.Models
{
    public class Person
    {
        private const int CURRENT_YEAR = 2025;

        // ✅ Parameterless constructor for MVC
        public Person() { }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Birth Year is required")]
        [Range(1900, CURRENT_YEAR, ErrorMessage = "Birth year must be between 1900 and current year")]
        public int BirthYear { get; set; }

        [DataType(DataType.Date)]
        public DateTime? Birthday { get; set; }

        public int AgeThisYear()
        {
            return CURRENT_YEAR - BirthYear;
        }

        public int AgeToday()
        {
            if (Birthday.HasValue)
            {
                var today = DateTime.Today;
                int age = today.Year - Birthday.Value.Year;
                if (Birthday.Value.Date > today.AddYears(-age)) age--;
                return age;
            }
            return AgeThisYear();
        }
    }
}
