﻿using Microsoft.AspNetCore.Mvc;

public class CustomRouteController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Custom Route Page";
        return View();
    }
}

