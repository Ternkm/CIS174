﻿using Microsoft.AspNetCore.Mvc;

public class DefaultPageController : Controller
{
    public IActionResult Index()
    {
        ViewData["Title"] = "Default Route Page";
        return View();
    }
}
