﻿using Microsoft.AspNetCore.Mvc;

public class AttributeRouteController : Controller
{
    [Route("my-attribute-page")]
    public IActionResult Index()
    {
        ViewData["Title"] = "Attribute Route Page";
        return View();
    }
}

