using Microsoft.AspNetCore.Mvc;
using FirstResponsiveWebAppMcMillan.Models;

namespace FirstResponsiveWebAppMcMillan.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new Person());
        }

        [HttpPost]
        public IActionResult Index(Person model, string submit)
        {
            if (submit == "Clear")
            {
                ModelState.Clear();
                return View(new Person());
            }

            if (ModelState.IsValid)
            {
                ViewBag.Result = $"Hello, {model.Name}! You will be {model.AgeThisYear()} years old on Dec 31, 2025.";

                if (model.Birthday.HasValue)
                {
                    ViewBag.Extra = $"As of today, you are {model.AgeToday()} years old.";
                }
            }

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}

